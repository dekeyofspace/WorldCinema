//
//  ViewController.swift
//  WorldCinema
//
//  Created by Student on 22.03.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var regbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

